<?php $__env->startSection('content'); ?>

<h1>Ini Adalah Content</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template_backend.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/berita/resources/views/home.blade.php ENDPATH**/ ?>