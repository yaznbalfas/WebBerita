@extends('template_backend.home')

@section('content')

<h1>Ini Adalah Content</h1>

@endsection